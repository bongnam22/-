import { useEffect, useMemo, useState } from "react"

type Category = "Promotion" | "Graphic" | "Branding"
type View = "home" | "project" | "about" | "contact"

type Project = {
  id: number
  title: string
  englishTitle: string
  category: Category
  shape: "landscape" | "portrait" | "square"
  year: string
  gray: string
}

const projects: Project[] = [
  {
    id: 1,
    title: "카이소캠페인",
    englishTitle: "KAISO Campaign",
    category: "Promotion",
    shape: "landscape",
    year: "2024. 03 — 05",
    gray: "#d8d8d6",
  },
  {
    id: 2,
    title: "KOTRA 60주년",
    englishTitle: "KOTRA 60th Anniversary",
    category: "Promotion",
    shape: "portrait",
    year: "2023. 08 — 11",
    gray: "#c9c9c6",
  },
  {
    id: 3,
    title: "광안리 펭수",
    englishTitle: "Pengsoo in Gwangalli",
    category: "Promotion",
    shape: "landscape",
    year: "2023. 06 — 08",
    gray: "#e2e2df",
  },
  {
    id: 4,
    title: "브레드이발소",
    englishTitle: "Bread Barbershop",
    category: "Promotion",
    shape: "square",
    year: "2023. 02 — 04",
    gray: "#bdbdb9",
  },
  {
    id: 5,
    title: "아라솔 캐릭터",
    englishTitle: "Arasol Character",
    category: "Graphic",
    shape: "square",
    year: "2022. 11 — 2023. 01",
    gray: "#d4d4d0",
  },
  {
    id: 6,
    title: "인생자취",
    englishTitle: "Living on My Own",
    category: "Branding",
    shape: "portrait",
    year: "2022. 08 — 10",
    gray: "#c4c4c1",
  },
  {
    id: 7,
    title: "파티타이거",
    englishTitle: "Party Tiger",
    category: "Branding",
    shape: "landscape",
    year: "2022. 04 — 07",
    gray: "#dededb",
  },
  {
    id: 8,
    title: "두심당",
    englishTitle: "Dusimdang",
    category: "Branding",
    shape: "portrait",
    year: "2021. 11 — 2022. 02",
    gray: "#babbb8",
  },
  {
    id: 9,
    title: "캠핑이나하라그렉",
    englishTitle: "Go Camping, Greg",
    category: "Branding",
    shape: "landscape",
    year: "2021. 07 — 10",
    gray: "#d0d0cd",
  },
]

const filters = ["All", "Promotion", "Graphic", "Branding"] as const

function Star({ size = 14 }: { size?: number }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 20 20"
      fill="none"
      aria-hidden="true"
    >
      <path
        d="M10 0.5C10.55 7.25 12.75 9.45 19.5 10C12.75 10.55 10.55 12.75 10 19.5C9.45 12.75 7.25 10.55 0.5 10C7.25 9.45 9.45 7.25 10 0.5Z"
        fill="currentColor"
      />
    </svg>
  )
}

function OrbitMark() {
  return (
    <div className="orbit-mark" aria-hidden="true">
      <svg viewBox="0 0 110 54" fill="none">
        <path
          d="M3 38C21 4 73 1 104 17C127 29 87 53 38 48"
          stroke="currentColor"
          strokeWidth="1"
          strokeDasharray="3 4"
        />
      </svg>
      <span>
        <Star size={9} />
      </span>
    </div>
  )
}

function Header({
  view,
  onNavigate,
}: {
  view: View
  onNavigate: (view: View) => void
}) {
  return (
    <header className="site-header">
      <button
        className="wordmark"
        onClick={() => onNavigate("home")}
        aria-label="Kim Bom home"
      >
        kimbom
      </button>
      <div className="logo-star">
        <Star size={10} />
      </div>
      <nav aria-label="Main navigation">
        <button
          className={view === "home" || view === "project" ? "active" : ""}
          onClick={() => onNavigate("home")}
        >
          Work
        </button>
        <button
          className={view === "about" ? "active" : ""}
          onClick={() => onNavigate("about")}
        >
          About
        </button>
        <button
          className={view === "contact" ? "active" : ""}
          onClick={() => onNavigate("contact")}
        >
          Contact
        </button>
      </nav>
    </header>
  )
}

function FilterTabs({
  active,
  onChange,
}: {
  active: string
  onChange: (value: string) => void
}) {
  return (
    <div className="filter-tabs" aria-label="Filter projects">
      {filters.map((filter) => (
        <button
          key={filter}
          className={active === filter ? "active" : ""}
          onClick={() => onChange(filter)}
        >
          {filter}
        </button>
      ))}
    </div>
  )
}

function ThumbnailCard({
  project,
  onOpen,
}: {
  project: Project
  onOpen: () => void
}) {
  return (
    <button
      className={`thumbnail-card ${project.shape}`}
      style={{ backgroundColor: project.gray }}
      onClick={onOpen}
      aria-label={`Open ${project.title} project`}
    >
      <span className="placeholder-index">
        {String(project.id).padStart(2, "0")}
      </span>
      <span className="placeholder-cross" aria-hidden="true" />
      <span className="thumbnail-label">
        <strong>{project.title}</strong>
        <span>{project.category}</span>
      </span>
    </button>
  )
}

function Footer({ onNavigate }: { onNavigate: (view: View) => void }) {
  return (
    <footer>
      <span>© 2025 Kim Bom</span>
      <button onClick={() => onNavigate("contact")}>
        Let’s work together ↗
      </button>
    </footer>
  )
}

function Home({
  onOpen,
  onNavigate,
}: {
  onOpen: (project: Project) => void
  onNavigate: (view: View) => void
}) {
  const [filter, setFilter] = useState("All")
  const visible = useMemo(
    () =>
      filter === "All"
        ? projects
        : projects.filter((project) => project.category === filter),
    [filter],
  )

  return (
    <main className="home-page page-enter">
      <div className="home-intro">
        <p>
          Graphic &amp; Brand Designer
          <br />
          based in Busan, Korea.
        </p>
        <FilterTabs active={filter} onChange={setFilter} />
      </div>
      <section className="masonry-grid" aria-live="polite">
        {visible.map((project) => (
          <ThumbnailCard
            key={project.id}
            project={project}
            onOpen={() => onOpen(project)}
          />
        ))}
      </section>
      <Footer onNavigate={onNavigate} />
    </main>
  )
}

function ImagePlaceholder({
  label,
  tone = "#d4d4d1",
  className = "",
}: {
  label: string
  tone?: string
  className?: string
}) {
  return (
    <div
      className={`detail-placeholder ${className}`}
      style={{ backgroundColor: tone }}
    >
      <span>{label}</span>
      <i aria-hidden="true" />
    </div>
  )
}

function ProjectDetail({
  project,
  onBack,
  onNext,
}: {
  project: Project
  onBack: () => void
  onNext: (project: Project) => void
}) {
  const next = projects[project.id % projects.length]

  return (
    <main className="project-page page-enter">
      <section className="project-hero">
        <ImagePlaceholder label="COVER IMAGE" tone={project.gray} />
        <div className="project-heading">
          <div>
            <p className="eyebrow">Selected work · {project.category}</p>
            <h1>{project.title}</h1>
            <p className="english-title">{project.englishTitle}</p>
          </div>
          <div className="project-meta">
            <div>
              <span>Period</span>
              <strong>{project.year}</strong>
            </div>
            <div className="tools">
              <span>Tools</span>
              <strong>Ai</strong>
              <strong>Ps</strong>
            </div>
          </div>
        </div>
      </section>

      <section className="overview section-space">
        <p className="section-label">01 / Overview</p>
        <div className="overview-copy">
          <h2>
            일상 속 새로운 장면을
            <br />
            만드는 디자인
          </h2>
          <div>
            <p>
              브랜드가 가진 고유한 이야기를 선명한 시각 언어로 정리했습니다.
              핵심 메시지를 쉽고 친근하게 전달하면서도, 다양한 매체에서 일관된
              인상을 만들 수 있도록 디자인 시스템을 구축했습니다.
            </p>
            <p>
              We translated the brand’s unique story into a clear visual
              language, creating a flexible system that stays distinctive and
              consistent across every touchpoint.
            </p>
          </div>
        </div>
      </section>

      <section className="system-section section-space">
        <p className="section-label">02 / Motif + Color System</p>
        <div className="system-grid">
          <div className="motif-canvas">
            <div className="motif-orbit" />
            <Star size={62} />
            <span>
              CORE
              <br />
              MOTIF
            </span>
          </div>
          <div className="swatches">
            <div style={{ background: "#111111", color: "#fff" }}>
              <span>Core Black</span>
              <small>#111111</small>
            </div>
            <div style={{ background: "#EF4E30" }}>
              <span>Signal Red</span>
              <small>#EF4E30</small>
            </div>
            <div style={{ background: "#F3D24F" }}>
              <span>Warm Yellow</span>
              <small>#F3D24F</small>
            </div>
            <div style={{ background: "#E9E9E6" }}>
              <span>Soft Gray</span>
              <small>#E9E9E6</small>
            </div>
          </div>
        </div>
      </section>

      <section className="gallery-section section-space">
        <ImagePlaceholder
          label="FULL WIDTH MOCKUP"
          tone="#c7c7c4"
          className="wide"
        />
        <div className="gallery-pair">
          <ImagePlaceholder label="APPLICATION 01" tone="#dededa" />
          <ImagePlaceholder label="APPLICATION 02" tone="#b9b9b6" />
        </div>
        <ImagePlaceholder
          label="BRAND EXPERIENCE"
          tone="#d2d2ce"
          className="wide tall"
        />
        <div className="gallery-pair offset">
          <ImagePlaceholder label="DETAIL 01" tone="#bfc0bd" />
          <ImagePlaceholder label="DETAIL 02" tone="#e1e1de" />
        </div>
      </section>

      <section className="project-end">
        <button className="back-link" onClick={onBack}>
          ← Back to all
        </button>
        <button className="next-project" onClick={() => onNext(next)}>
          <span>Next project</span>
          <strong>{next.title}</strong>
          <i>↗</i>
        </button>
      </section>
    </main>
  )
}

function Globe() {
  return (
    <div className="globe-wrap" aria-label="Kim Bom globe illustration">
      <svg viewBox="0 0 260 260" role="img">
        <defs>
          <radialGradient id="globeGradient" cx="35%" cy="28%" r="75%">
            <stop offset="0%" stopColor="#f8f8f6" />
            <stop offset="60%" stopColor="#c5c8c2" />
            <stop offset="100%" stopColor="#8e918d" />
          </radialGradient>
          <path id="curve" d="M42,145 A92,92 0 0,1 218,145" />
        </defs>
        <circle cx="130" cy="140" r="72" fill="url(#globeGradient)" />
        <ellipse
          cx="130"
          cy="140"
          rx="72"
          ry="23"
          fill="none"
          stroke="#fff"
          strokeOpacity=".6"
        />
        <ellipse
          cx="130"
          cy="140"
          rx="26"
          ry="72"
          fill="none"
          stroke="#fff"
          strokeOpacity=".6"
        />
        <path
          d="M62 116C103 130 161 129 199 109M63 168C105 151 160 153 198 173"
          fill="none"
          stroke="#fff"
          strokeOpacity=".5"
        />
        <text className="curve-text">
          <textPath href="#curve" startOffset="50%" textAnchor="middle">
            KIM BOM · GRAPHIC DESIGNER ·
          </textPath>
        </text>
      </svg>
      <div className="globe-star">
        <Star size={24} />
      </div>
    </div>
  )
}

function About({ onNavigate }: { onNavigate: (view: View) => void }) {
  return (
    <main className="about-page page-enter">
      <section className="about-hero">
        <div>
          <p className="eyebrow">About me</p>
          <h1>
            Ideas in orbit,
            <br />
            stories in form.
          </h1>
          <p className="about-lead">
            안녕하세요. 브랜드의 이야기를 발견하고 시각적인 경험으로 연결하는
            그래픽 디자이너 김봄입니다.
          </p>
        </div>
        <Globe />
      </section>

      <section className="profile-grid">
        <div>
          <p className="section-label">Experience</p>
          <ul>
            <li>
              <strong>Freelance Designer</strong>
              <span>2023 — Present</span>
            </li>
            <li>
              <strong>Studio B, Designer</strong>
              <span>2021 — 2023</span>
            </li>
            <li>
              <strong>Design Intern</strong>
              <span>2020 — 2021</span>
            </li>
          </ul>
        </div>
        <div>
          <p className="section-label">Education</p>
          <ul>
            <li>
              <strong>Visual Communication Design</strong>
              <span>Dongseo University, 2021</span>
            </li>
          </ul>
          <p className="section-label sub-label">Certificate / Skills</p>
          <p>
            GTQ Graphic Technology
            <br />
            Brand identity · Editorial · Campaign
          </p>
        </div>
        <div>
          <p className="section-label">Software</p>
          <div className="pill-list">
            <span>Illustrator</span>
            <span>Photoshop</span>
            <span>After Effects</span>
          </div>
        </div>
        <div>
          <p className="section-label">Interests</p>
          <div className="interest-list">
            <span>
              <i>◯</i>Space
            </span>
            <span>
              <i>⌁</i>Sea
            </span>
            <span>
              <i>♬</i>Music
            </span>
            <span>
              <i>△</i>Camping
            </span>
          </div>
        </div>
      </section>
      <Footer onNavigate={onNavigate} />
    </main>
  )
}

function Contact() {
  return (
    <main className="contact-page page-enter">
      <div className="contact-content">
        <p className="eyebrow">Say hello</p>
        <h1>Contact</h1>
        <p>
          새로운 프로젝트와 즐거운 협업 이야기를 기다리고 있어요.
          <br />
          Feel free to get in touch for projects or collaborations.
        </p>
        <div className="contact-links">
          <a href="mailto:hello@kimbom.design">
            <span>Email</span>hello@kimbom.design ↗
          </a>
          <a href="https://instagram.com" target="_blank" rel="noreferrer">
            <span>Instagram</span>@bom.design ↗
          </a>
        </div>
      </div>
      <div className="contact-orbit">
        <OrbitMark />
      </div>
      <div className="contact-bottom">
        <span>Busan, South Korea</span>
        <span>© 2025 Kim Bom</span>
      </div>
    </main>
  )
}

export default function App() {
  const [view, setView] = useState<View>("home")
  const [selectedProject, setSelectedProject] = useState<Project>(projects[0])

  const navigate = (nextView: View) => {
    setView(nextView)
    window.scrollTo({ top: 0, behavior: "smooth" })
  }

  const openProject = (project: Project) => {
    setSelectedProject(project)
    navigate("project")
  }

  useEffect(() => {
    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key === "Escape" && view === "project") navigate("home")
    }
    window.addEventListener("keydown", onKeyDown)
    return () => window.removeEventListener("keydown", onKeyDown)
  }, [view])

  return (
    <div className="app-shell">
      <Header view={view} onNavigate={navigate} />
      {view === "home" && <Home onOpen={openProject} onNavigate={navigate} />}
      {view === "project" && (
        <ProjectDetail
          project={selectedProject}
          onBack={() => navigate("home")}
          onNext={openProject}
        />
      )}
      {view === "about" && <About onNavigate={navigate} />}
      {view === "contact" && <Contact />}
    </div>
  )
}
